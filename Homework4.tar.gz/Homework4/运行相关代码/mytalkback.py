#!/usr/bin/env python

"""
    talkback.py - Version 1.1 2013-12-20
    
    Use the sound_play client to say back what is heard by the pocketsphinx recognizer.
    
"""

import rospy, os, sys
from std_msgs.msg import String
from sound_play.libsoundplay import SoundClient

class TalkBack:
    def __init__(self, script_path):
        rospy.init_node('mytalkback')

        rospy.on_shutdown(self.cleanup)
        
        # Create the sound client object
        self.soundhandle = SoundClient()
        
        # Wait a moment to let the client connect to the
        # sound_play server
        rospy.sleep(1)
        
        # Make sure any lingering sound_play processes are stopped.
        self.soundhandle.stopAll()
        
        # Announce that we are ready for input
        #self.soundhandle.playWave('say-beep.wav')
        #rospy.sleep(2)
        #self.soundhandle.say('Ready')
        
        rospy.loginfo("your words:")

        # Subscribe to the recognizer output and set the callback function
        rospy.Subscriber('/lm_data', String, self.talkback)
        
    def talkback(self, msg):
        # Print the recognized words on the screen
        rospy.loginfo(msg.data)
        
        # Speak the recognized words in the selected voice
        if msg.data.find('HELLO')>-1:
        	#rospy.sleep(1)
                rospy.loginfo(msg.data)
		self.soundhandle.say("Hi,nice to meet you!")
                rospy.loginfo("Hi,nice to meet you!")
		rospy.sleep(2) 
        elif msg.data.find('WHAT IS YOUR NAME')>-1:
        	#rospy.sleep(1)
		self.soundhandle.say("My name is siri")
                rospy.loginfo("My name is siri")
		rospy.sleep(2) 
        elif msg.data.find('WHERE ARE YOU FROM')>-1:
        	#rospy.sleep(1)
		self.soundhandle.say("I am from China")
                rospy.loginfo("I am from China")
		rospy.sleep(2) 
        elif msg.data.find('WHAT DO YOU WANT')>-1:
        	#rospy.sleep(1)
		self.soundhandle.say("I just want to talk with someone")
                rospy.loginfo("I just want to talk with someone")
		rospy.sleep(2)
        else:   
		rospy.sleep(2)
 
    def cleanup(self):
        self.soundhandle.stopAll()
        rospy.loginfo("Shutting down talkback node...")

if __name__=="__main__":
    try:
        TalkBack(sys.path[0])
        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("Talkback node terminated.")
